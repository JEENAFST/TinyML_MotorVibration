################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (14.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Src/Led.c \
../Src/main.c \
../Src/syscalls.c \
../Src/sysmem.c \
../Src/vibration_model.c 

OBJS += \
./Src/Led.o \
./Src/main.o \
./Src/syscalls.o \
./Src/sysmem.o \
./Src/vibration_model.o 

C_DEPS += \
./Src/Led.d \
./Src/main.d \
./Src/syscalls.d \
./Src/sysmem.d \
./Src/vibration_model.d 


# Each subdirectory must supply rules for building sources it contributes
Src/%.o Src/%.su Src/%.cyclo: ../Src/%.c Src/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DSTM32 -DSTM32F407G_DISC1 -DSTM32F4 -DSTM32F407VGTx -c -I../Inc -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-Src

clean-Src:
	-$(RM) ./Src/Led.cyclo ./Src/Led.d ./Src/Led.o ./Src/Led.su ./Src/main.cyclo ./Src/main.d ./Src/main.o ./Src/main.su ./Src/syscalls.cyclo ./Src/syscalls.d ./Src/syscalls.o ./Src/syscalls.su ./Src/sysmem.cyclo ./Src/sysmem.d ./Src/sysmem.o ./Src/sysmem.su ./Src/vibration_model.cyclo ./Src/vibration_model.d ./Src/vibration_model.o ./Src/vibration_model.su

.PHONY: clean-Src

